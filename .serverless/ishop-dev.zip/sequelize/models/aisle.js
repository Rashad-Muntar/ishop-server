"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Aisle extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Aisle.belongsTo(models.Store, {
        foreignKey: 'storeId',
        as: 'store'
      });
      Aisle.hasMany(models.Product, {
        foreignKey: 'aisleId',
        as: 'products'
      });
    }
  }
  Aisle.init(
    {
      id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
      },
      title: DataTypes.STRING,
      image: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Aisle",
    }
  );
  return Aisle;
};
